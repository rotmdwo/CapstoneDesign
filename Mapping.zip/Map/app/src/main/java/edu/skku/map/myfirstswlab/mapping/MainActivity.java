package edu.skku.map.myfirstswlab.mapping;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.Toast;

import net.daum.mf.map.api.MapPOIItem;
import net.daum.mf.map.api.MapPoint;
import net.daum.mf.map.api.MapView;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


public class MainActivity extends AppCompatActivity implements MapView.POIItemEventListener{



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //맵뷰 띄우기
        MapView mapView = new MapView(this);

        ViewGroup mapViewContainer = (ViewGroup) findViewById(R.id.map_view);
        mapViewContainer.addView(mapView);

        //중심 설정
        mapView.setMapCenterPoint(MapPoint.mapPointWithGeoCoord(37.294019, 126.975399), true);

        //마커 띄우기
        MapPOIItem marker = new MapPOIItem();
        marker.setItemName("Default Marker");
        marker.setTag(0);
        marker.setMapPoint(MapPoint.mapPointWithGeoCoord(37.294019, 126.975399));
        marker.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin);

        mapView.addPOIItem(marker);

        //리스너 등록

        mapView.setPOIItemEventListener(this);

        onPOIItemSelected(mapView,marker);





    }

    @Override
    protected void onResume() {

        super.onResume();




    }

    @Override
    public void onPOIItemSelected(MapView mapView, MapPOIItem poiItem){
        double[] list = new double[2];
        list[0] =poiItem.getMapPoint().getMapPointGeoCoord().latitude;
        list[1] =poiItem.getMapPoint().getMapPointGeoCoord().longitude;


        Toast myToast = Toast.makeText(this.getApplicationContext(),String.valueOf(list[0])+ "/" + String.valueOf(list[1]) ,Toast.LENGTH_SHORT);
        myToast.show();


    }

    @Override
    public void onCalloutBalloonOfPOIItemTouched(MapView mapView, MapPOIItem mapPOIItem) {

    }

    @Override
    public void onCalloutBalloonOfPOIItemTouched(MapView mapView, MapPOIItem mapPOIItem, MapPOIItem.CalloutBalloonButtonType calloutBalloonButtonType) {

    }

    @Override
    public void onDraggablePOIItemMoved(MapView mapView, MapPOIItem mapPOIItem, MapPoint mapPoint) {

    }

    abstract public static class Activity implements MapView.POIItemEventListener {

    }





    



}
